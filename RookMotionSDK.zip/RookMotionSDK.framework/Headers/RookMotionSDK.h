//
//  RookMotionSDK.h
//  RookMotionSDK
//
//  Created by Francisco Rook on 14/04/21.
//

#import <Foundation/Foundation.h>

//! Project version number for RookMotionSDK.
FOUNDATION_EXPORT double RookMotionSDKVersionNumber;

//! Project version string for RookMotionSDK.
FOUNDATION_EXPORT const unsigned char RookMotionSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RookMotionSDK/PublicHeader.h>


